// STUDENT FOCUS: Constants and Scales
// maxRadius is our maximum visual size for circles.
var maxRadius = 35;

// rScale (radius scale) maps the number of entrants (0 to 210) to our radius range (0 to maxRadius).
// scaleSqrt is commonly used for radius because circle area is proportional to the square of the radius.
var rScale = d3.scaleSqrt().domain([0, 210]).range([0, maxRadius]);

// Mapping country names to specific colors to represent the winner's nationality.
var colorScale = {
  "France": '#016FB9',
  "Luxembourg": '#C6E0FF',
  "Belgium": '#555',
  "Italy": '#58BC82',
  "Switzerland": '#D16462',
  "Spain": '#FFC400',
  "Netherlands": '#F86018',
  "USA": '#74B0D8',
  "Ireland Irish": '#FFF',
  "Denmark": '#EBBCBB',
  "Germany": '#FFCE00',
  "Australia": '#013D65',
  "United Kingdom": '#B80C09',
  "Results voided": 'none'
}
var popup;

// STUDENT FOCUS: Data Layout Logic
// This function determines where each year's data point will be drawn on the SVG canvas.
function layout(data) {
  var numCols = 10, cellSize = 80;
  data.forEach(function(d) {
    d.layout = {}; // Create an object to store calculated visual properties.
    var i = d.Year - 1900;

    // Calculate columns (x) and rows (y) based on the year index.
    var col = i % numCols;
    d.layout.x = col * cellSize + 0.5 * cellSize;

    var row = Math.floor(i / numCols);
    d.layout.y = row * cellSize + 0.5 * cellSize;

    // Calculate radii based on the data and our rScale defined earlier.
    d.layout.entrantsRadius = rScale(d.Entrants);
    d.layout.finishersRadius = rScale(d.Finishers);
  });
}

// Function to generate the HTML content for the hover popup.
function popupTemplate(d) {
  var year = +d.Year;
  var distance = +d["Total distance (km)"];
  var entrants = +d.Entrants;
  var finishers = +d.Finishers;
  var winner = d.Winner;
  var nationality = d["Winner's Nationality"];

  var html = '';
  html += '<table><tbody>';
  html += '<tr><td>Year</td><td>' + year + '</td></tr>';
  html += '<tr><td>Total distance</td><td>' + distance + 'km</td></tr>';
  html += '<tr><td>Entrants</td><td>' + entrants + '</td></tr>';
  html += '<tr><td>Finishers</td><td>' + finishers + '</td></tr>';
  html += '<tr><td>Winner</td><td>' + winner + '</td></tr>';
  html += '<tr><td>Nationality</td><td>' + nationality + '</td></tr>';
  html += '</tbody></table>';
  return html;
}

// STUDENT FOCUS: Updating the visualization with D3.js.
// This is where the core D3 "selection -> join" pattern happens.
function updateChart(data) {
  // First, calculate all the layout positions.
  layout(data);

  // 1. Render the 'entrants' circles (the large outer dashed circles).
  d3.select('svg g.chart g.entrants')
    .selectAll('circle')
    .data(data)
    .join('circle') // join manages creating, updating, and removing circles based on data.
    .attr('cx', function(d) {
      return d.layout.x;
    })
    .attr('cy', function(d) {
      return d.layout.y;
    })
    .attr('r', function(d) {
      return d.layout.entrantsRadius;
    })
    .style('fill', 'none')
    .style('stroke', '#aaa')
    .style('stroke-dasharray', '1 1');

  // 2. Render the 'finishers' circles (the grey circles representing completions).
  // Includes hover interactions for showing popups.
  d3.select('svg g.chart g.finishers')
    .selectAll('circle')
    .data(data)
    .join('circle')
    .attr('cx', function(d) {
      return d.layout.x;
    })
    .attr('cy', function(d) {
      return d.layout.y;
    })
    .attr('r', function(d) {
      return d.layout.finishersRadius;
    })
    .style('fill', '#aaa')
    .on('mousemove', function(d) {
      // Use Flourish popup to show details on mouse hover.
      popup.point(d3.event.clientX, d3.event.clientY);
      popup.html(popupTemplate(d));
      popup.draw();
    })
    .on('mouseout', function() {
      // Hide popup when mouse leaves the circle.
      popup.hide();
    });

  // 3. Render the 'winners' circles (the small colored circles in the center).
  d3.select('svg g.chart g.winners')
    .selectAll('circle')
    .data(data)
    .join('circle')
    .attr('cx', function(d) {
      return d.layout.x;
    })
    .attr('cy', function(d) {
      return d.layout.y;
    })
    .attr('r', 5)
    .style('pointer-events', 'none') // Prevents this circle from blocking the mouse events of the circle below it.
    .style('fill', function(d) {
      // Use the winner's nationality to look up a color in our colorScale.
      return colorScale[d["Winner's Nationality"].trim()];
    });
}

// Function to add the year labels on the left side.
function updateYearLabels() {
  var years = [1900, 1910, 1920, 1930, 1940, 1950, 1960, 1970, 1980, 1990, 2000, 2010];
  var cellSize = 80;
  d3.select('svg g.chart .year-labels')
    .selectAll('text')
    .data(years)
    .join('text')
    .attr('y', function(d, i) {
      return i * cellSize + 0.5 * cellSize;
    })
    .attr('dy', '0.3em')
    .style('text-anchor', 'end')
    .style('fill', '#555')
    .style('font-weight', 'bold')
    .text(function(d) {
      return d;
    });
}

// Function to generate the legend from the country keys.
function updateLegend() {
  var countries = Object.keys(colorScale);
  d3.select('.legend')
    .selectAll('div')
    .data(countries)
    .join('div')
    .html(function(d) {
      return '<span style="background-color: ' + colorScale[d] + ';"></span><span>' + d + '</span>';
    });
}

// This function coordinates everything once the CSV data is loaded.
function dataIsReady(data) {
  updateChart(data);
  updateYearLabels();
  updateLegend();
  popup = Popup(); // Initialize the Flourish Popup library.
}

// STUDENT FOCUS: Data Loading
// This starts the whole process by reading our CSV data and then calling dataIsReady.
d3.csv('data/tour_de_france.csv')
  .then(dataIsReady);
